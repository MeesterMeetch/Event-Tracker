# Outcome Grading and Calibration: Integration Notes

What this adds: paper trades get settled against actual boxscore strikeouts, giving the Model Performance page a calibration story (Brier score, reliability buckets, settled ROI) alongside CLV.

## Step 1. Schema

Add two columns to `lib/db/src/schema/pitcher-k-paper-trades.ts`, next to the CLV fields:

```ts
// Filled by the outcome-grading job once the game is final. Kept independent
// of the CLV lifecycle (`status`): an "expired" trade still gets an outcome.
actualStrikeouts: integer("actual_strikeouts"),
outcome: text("outcome"), // "won" | "lost" | "push" | "void" | null (unsettled)
```

Then push: `pnpm --filter @workspace/db run push`

## Step 2. OpenAPI spec

Add the same two fields to the PaperTrade schema in `lib/api-spec/openapi.yaml`:

```yaml
actualStrikeouts:
  type: integer
  nullable: true
  description: Pitcher's actual strikeout total once the game is final.
outcome:
  type: string
  nullable: true
  enum: [won, lost, push, void]
  description: Settled result of the selection against the actual total.
```

Then regenerate: `pnpm --filter @workspace/api-spec run codegen`

Per your memory notes, after regen check `api-zod` and `api-client-react` index.ts for duplicated `export *` lines, dedupe, then run `tsc -b` on each changed lib so consumers see fresh dist types.

## Step 3. API server files

Copy `k-outcome-math.ts` and `k-outcome-math.test.ts` and `k-outcomes.ts` into `artifacts/api-server/src/lib/`.

Append the contents of `mlb-boxscore-addition.ts` to `artifacts/api-server/src/lib/mlb.ts` (it reuses the existing `mlbFetch`, `easternDate`, `norm`, `int`, and `MLB_SPORT_ID` already in that file, so drop the leading comment block wherever it reads cleanest and delete nothing).

Wire the scheduler in `artifacts/api-server/src/index.ts`:

```ts
import { startKOutcomeGrading } from "./lib/k-outcomes";
// alongside the other start calls:
startKOutcomeGrading();
```

No API key needed; it is the same free MLB Stats API you already use.

## Step 4. Web app

Copy `calibration.ts` and `calibration.test.ts` into `artifacts/ev-tracker/src/lib/`.

Suggested additions to ModelPerformance.tsx, in order of value:

1. A Brier score stat card next to beat-close rate, with the 0.25 coin-flip reference labeled so the number reads at a glance.
2. A reliability chart from `calibrationBuckets`: predicted on x, actual on y, diagonal reference line, bucket count shown on hover so thin buckets are not over-read.
3. A settled ROI card from `settledRoi` for the flagged subset, which is the honest "would this have made money at flat stakes" number.

## Design decisions worth knowing

The outcome lifecycle is deliberately separate from CLV status. A trade whose closing line was never captured still deserves an outcome, and vice versa, so `outcome` is its own nullable column rather than new status values.

Void mirrors sportsbook behavior: if the pitcher never appears in the final boxscore the prop would have been voided at the book, so it is excluded from calibration and ROI.

The MLB fetcher returns a discriminated union (`final`, `notFinal`, `didNotPitch`, `gameNotFound`) instead of nulls or zeroed stats. That is intentional per your "MLB K inputs degrade silently" memory note; the compiler now forces the job to handle every state, and abstain-and-retry is the default for anything ambiguous.

Trades logged before `pitcherId` existed are skipped up front rather than warned about every run, matching the AUTO_GRADABLE_MARKETS pattern in grading.ts.

## What this unlocks next

Once a few weeks of settled outcomes accumulate, the calibration buckets will tell you whether the binomial's tails are too confident (actual hit rates pulled toward 50 percent relative to predicted in the outer buckets is the signature). That is the empirical green light for the beta binomial change, and the same settled data becomes the loss function for backtesting FORM_PRIOR_BF and CAREER_PRIOR_BF.
